package org.deuce.transaction.global;

final public class Lock {
    final public static Object lock = new Object();
}
